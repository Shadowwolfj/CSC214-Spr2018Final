-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2018 at 11:09 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mythicalflights`
--

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `flight_num` int(8) NOT NULL,
  `depart_city` text NOT NULL,
  `arrival_city` text NOT NULL,
  `flight_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flight_num`, `depart_city`, `arrival_city`, `flight_date`) VALUES
(3172000, 'Jackson, Mississippi, United States', 'Paris, France', '2018-04-28'),
(9131985, 'Jackson, Mississippi, United States', 'Las Vegas, Nevada, United States', '2018-04-28'),
(11211994, 'Biloxi, Mississippi, United States', 'Brasilia, Brazil', '2018-04-27'),
(2211985, 'Atlanta, Georgia, United States', 'Richmond, Virginia, United States', '2018-04-26'),
(8061986, 'Jackson, Mississippi, United States', 'Oklahoma City, Oklahoma, United States', '2018-04-28'),
(8051995, 'Biloxi, Mississippi, United States', 'Havana, Cuba', '2018-04-28'),
(4271992, 'Jackson, Mississippi, United States', 'Orlando, Florida, United States', '2018-04-27'),
(2211993, 'Jackson, Mississippi, United States', 'New York City, New York, United States', '2018-04-25'),
(9281998, 'Jackson, Mississippi, United States', 'Osaka, Japan', '2018-04-29'),
(6091995, 'Batesville, Jackson, United States', 'Cincinnati, Ohio, United States', '2018-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `last_name` text NOT NULL,
  `first_name` text NOT NULL,
  `flight_num` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`last_name`, `first_name`, `flight_num`) VALUES
('Mursh', 'Mario', 3172000),
('Mursh', 'Luigi', 3172000),
('Kong', 'Donkey', 3172000),
('Hylia', 'Link', 3172000),
('Aran', 'Samus', 3172000),
('Sinez', 'Ness', 3172000),
('Toadstool', 'Peach', 9131985),
('Thibank', 'Robin', 2211985),
('McCloud', 'Fox', 3172000),
('Lombardi', 'Falco', 2211993),
('Chimaru', 'Pika', 3172000),
('Purin', 'Jessica', 9281998),
('Star', 'Kirby', 3172000),
('Dedede', 'Harold', 4271992),
('Clark', 'Armon', 6091995),
('Kong', 'Diddy', 11211994),
('McMillan', 'Jai-Michael', 9281998),
('Clark', 'Aaron', 2211993),
('Mitsu', 'Yoshi', 8051995),
('Kamui', 'Yoshi', 3172000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
